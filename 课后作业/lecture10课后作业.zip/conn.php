<?php
$dsn = 'mysql:dbname=mybook;host=localhost;charset=utf8';
$user = 'root';
$pwd = 'root';

try
{
    $dbh = new PDO($dsn, $user, $pwd);
}catch(PDOException $e)
{
    echo '数据库连接错误'.$e->getMessage();
    exit;
}
?>